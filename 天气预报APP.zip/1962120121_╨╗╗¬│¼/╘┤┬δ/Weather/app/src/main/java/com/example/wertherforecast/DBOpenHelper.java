package com.example.wertherforecast;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class DBOpenHelper extends SQLiteOpenHelper {
    //定义对象
    private static final String TAG = DBOpenHelper.class.getSimpleName();
    private static String httpString = "https://way.jd.com/jisuapi/weather1?appkey=d23bcdb184c82648e4d6dc3e09d34416";
    private CityBean cityBean;
    private CityBean.ResultDTO resultDTO;
    private CityBean.ResultDTO.ResultsDTO resultsDTO;
    private List<CityBean.ResultDTO.ResultsDTO> cityBeanList = null;
    private String json;
    //数据库版本
    private static final int DATABASE_VERSION=3;
    //数据库名称
    private static final String DATABASE_NAME="citysix.db";

    public DBOpenHelper( Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        Log.i( TAG,"我真的在建数据库" );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i( TAG,"我在建onCreate" );
        //得到city
        boolean v = true;
        while(cityBeanList==null) {
            if(v) {
                v = false;
                getJson( "GG" );
            }
        }
        db.execSQL("create table IF NOT EXISTS citythree( id varchar primary key, name varchar, pinyin varchar, mark INTEGER)");
        System.out.println("我yao插入了所有城市数据： "+ cityBeanList);
        //插入所有city数据
        for (int i = 0 ; i<cityBeanList.size(); i++){
            ContentValues values = new ContentValues();
            values.put("id",cityBeanList.get(i).getCityid());
            values.put("name",cityBeanList.get(i).getCity());
            values.put("pinyin",cityBeanList.get(i).getCitycode());
            values.put("mark",0);
            db.insert("citythree",null,values);
        }
        System.out.println("我插入了所有城市数据： "+ cityBeanList);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //创建线程池
    private ExecutorService threadPool = new ThreadPoolExecutor(
            2,//默认核心线程池大小
            Runtime.getRuntime().availableProcessors(),//最大核心线程池大小，模拟器是4核
            30,//超时等待时间，没人调用就释放
            TimeUnit.SECONDS,//超时时间单位
            new LinkedBlockingDeque<>(2),//阻塞队列，最大可排队等待的线程个数
            Executors.defaultThreadFactory(),//线程工厂，创建线程
            new ThreadPoolExecutor.DiscardOldestPolicy()//拒绝策略，尝试竞争老的线程
    );

    //获取json信息
    private void getJson(String cityName){
        //处理得到url
        String urlString = httpString;
        Log.i( TAG,"nows urlString "+urlString );
        //通过线程池开启线程获取天气信息
        threadPool.execute(()->{
            //通过网络资源获取json数据
            Log.i( TAG,"nows myjson " );
            String myJson = HttpUtil.getJsonInfo(urlString);
            Log.i( TAG,"nows myjson "+myJson );
            //如果资源获取成功
            if (myJson != null) {
                Log.i(TAG,"now 请求成功 "+cityName);
                json = myJson;
                gsonObject();
                return;
            } else {
                Log.i(TAG,"now 请求失败 "+cityName);
            }
        });
    }

    //gson解析
    private void gsonObject( ) {
        //创建gson对象
        Gson gson = new Gson();
        //gson解析获得weatherBean对象
        Log.i(TAG,"now json is "+json);
        cityBean = gson.fromJson(json, CityBean.class);
        Log.i(TAG,"now "+cityBean);
        resultDTO = cityBean.getResult();
        Log.i(TAG,"now "+resultDTO);
        cityBeanList = resultDTO.getResult();
        Log.i(TAG,"now "+cityBeanList);
    }
}

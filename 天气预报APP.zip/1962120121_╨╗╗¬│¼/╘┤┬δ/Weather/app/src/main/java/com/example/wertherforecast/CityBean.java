package com.example.wertherforecast;

import java.util.List;

public class CityBean {
    private String code;
    private String charge;
    private String msg;
    private ResultDTO result;

    @Override
    public String toString() {
        return "CityBean{" +
                "code='" + code + '\'' +
                ", charge='" + charge + '\'' +
                ", msg='" + msg + '\'' +
                ", result=" + result +
                '}';
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public ResultDTO getResult() {
        return result;
    }

    public void setResult(ResultDTO result) {
        this.result = result;
    }

    public static class ResultDTO {
        private Integer status;
        private String msg;
        private List<ResultsDTO> result;

        @Override
        public String toString() {
            return "ResultDTO{" +
                    "status=" + status +
                    ", msg='" + msg + '\'' +
                    ", result=" + result +
                    '}';
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public List<ResultsDTO> getResult() {
            return result;
        }

        public void setResult(List<ResultsDTO> result) {
            this.result = result;
        }

        public static class ResultsDTO {
            private String cityid;
            private String parentid;
            private String citycode;
            private String city;

            @Override
            public String toString() {
                return "ResultsDTO{" +
                        "cityid='" + cityid + '\'' +
                        ", parentid='" + parentid + '\'' +
                        ", citycode='" + citycode + '\'' +
                        ", city='" + city + '\'' +
                        '}';
            }

            public String getCityid() {
                return cityid;
            }

            public void setCityid(String cityid) {
                this.cityid = cityid;
            }

            public String getParentid() {
                return parentid;
            }

            public void setParentid(String parentid) {
                this.parentid = parentid;
            }

            public String getCitycode() {
                return citycode;
            }

            public void setCitycode(String citycode) {
                this.citycode = citycode;
            }

            public String getCity() {
                return city;
            }

            public void setCity(String city) {
                this.city = city;
            }
        }
    }
}
package com.example.wertherforecast;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.gson.Gson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity  {
    //打印异常
    private static final String TAG = MainActivity.class.getSimpleName();
    //定义对象
    private WeatherBean weatherBean;
    private WeatherBean.ResultDTO resultDTO;
    private WeatherBean.ResultDTO.ResultsDTO resultDTOs;
    private WeatherBean.ResultDTO.ResultsDTO.AqiDTO aqiDTO;
    private WeatherBean.ResultDTO.ResultsDTO.AqiDTO.AqiinfoDTO aqiinfoDTO;
    private WeatherBean.ResultDTO.ResultsDTO.DailyDTO dailyDTO;
    private WeatherBean.ResultDTO.ResultsDTO.DailyDTO.DayDTO dayDTO;
    private WeatherBean.ResultDTO.ResultsDTO.HourlyDTO hourlyDTO;
    private WeatherBean.ResultDTO.ResultsDTO.DailyDTO.NightDTO nightDTO;
    private List<WeatherBean.ResultDTO.ResultsDTO.HourlyDTO> hourlyDTOList;
    private List<WeatherBean.ResultDTO.ResultsDTO.IndexDTO> indexDTOList;
    private List<WeatherBean.ResultDTO.ResultsDTO.DailyDTO> dailyDTOList;
    private static String httpString = "https://way.jd.com/jisuapi/weather?city=";
    private String cityName = "广州";
    private String json;
    private AnimationDrawable animation;
    //定义控件
    private ImageView background_iv;
    private TextView data;
    private TextView city;
    private TextView weather;
    private TextView temp;
    private TextView hightemp;
    private TextView week;
    private TextView lowtemp;
    private Button quality;
    private Button city_add_can;
    private TextView color4;
    private TextView color5;
    private TextView color6;
    private Button color7;
    private TextView color14;
    //创建线程池
    private ExecutorService threadPool = new ThreadPoolExecutor(
            2,//默认核心线程池大小
            Runtime.getRuntime().availableProcessors(),//最大核心线程池大小，模拟器是4核
            30,//超时等待时间，没人调用就释放
            TimeUnit.SECONDS,//超时时间单位
            new LinkedBlockingDeque<>(2),//阻塞队列，最大可排队等待的线程个数
            Executors.defaultThreadFactory(),//线程工厂，创建线程
            new ThreadPoolExecutor.DiscardOldestPolicy()//拒绝策略，尝试竞争老的线程
    );
    //创建map缓存信息，线程安全，解决java.util.ConcurrentModificationException并发修改异常
    private Map<String, JsonAndTime> jsonMap = new ConcurrentHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        //加载界面布局
        setContentView(R.layout.activity_main);
        //初始化控件
        initview();
        //获取json信息
        //getJson(cityName);
    }

    // 主线程创建消息处理器
    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            //200则成功
            if (msg.what == 200) {
                //接收线程获取的资源
                json = (String) msg.obj;
                //gson解析获取对象
                gsonObject();
                //显示天气数据
                showdata();
            } else if (msg.what == 0) {
                Toast.makeText(MainActivity.this, "请检查网络", Toast.LENGTH_SHORT).show();
            }
        }
    };

    //初始化控件
    private void initview() {
        background_iv = findViewById(R.id.background_iv);
        city = findViewById(R.id.city_tv);
        temp = findViewById(R.id.temp);
        weather = findViewById( R.id.weather );
        data = findViewById(R.id.data);
        week = findViewById(R.id.week);
        hightemp = findViewById(R.id.hightemp);
        lowtemp = findViewById(R.id.lowtemp);
        quality = findViewById( R.id.quality );
        city_add_can = findViewById( R.id.city_add_can );
        color4 = findViewById( R.id.color4 );
        color5 = findViewById( R.id.color5 );
        color6 = findViewById( R.id.color6 );
        color7 = findViewById( R.id.color7 );
        color14 = findViewById( R.id.color14 );
    }

    //获取json信息
    private void getJson(String cityName){
        //创建消息
        Message message = new Message();
        //判断是否有缓存
        if (jsonMap.containsKey(cityName)){
            //判断时间戳是否相差30000ms即30s
            if (System.currentTimeMillis() - jsonMap.get(cityName).getCurrentTime() <= 30000){
                //如果30s内有获取过，则取出使用
                String myJson = jsonMap.get(cityName).getJson();
                //设置消息类型
                message.what = 200;
                //设置传送的数据
                message.obj = myJson;
                //发送消息到消息队里进行下一步操作
                handler.sendMessage(message);
                //返回，结束方法
                return;
            }
        }
        //处理得到url
        String urlString = httpString + cityName+"&cityid=&citycode=&appkey=6fb453cf64e657103321d6e4c4d2c031";
        //通过线程池开启线程获取天气信息
        threadPool.execute(()->{
            //通过网络资源获取json数据
            String myJson = HttpUtil.getJsonInfo(urlString);
            Log.i( TAG,"nows myjson "+myJson );
            //如果资源获取成功
            if (myJson != null) {
                Log.i(TAG,"now 请求成功 "+cityName);
                //存入map中
                jsonMap.put(cityName,new JsonAndTime(System.currentTimeMillis(),myJson));
                //System.out.println(jsonMap);
                //System.out.println(jsonMap.get(cityName).toString());
                //调用自身再次尝试获取json数据
                getJson(cityName);
                Log.i(TAG,"now "+cityName);
            } else {
                System.out.println("请求失败");
                //设置消息类型
                message.what = 0;
                //设置传送的数据
                message.obj = null;
                //发送消息到消息队里进行下一步操作
                handler.sendMessage(message);
            }
        });
    }

    //gson解析
    private void gsonObject() {
        //创建gson对象
        Gson gson = new Gson();
        //gson解析获得weatherBean对象
        Log.i(TAG,"now json is "+json);
        weatherBean = gson.fromJson(json, WeatherBean.class);
        Log.i(TAG,"now "+weatherBean);
        //从weatherBean对象中获取cityInfo对象
        resultDTO = weatherBean.getResult();
        Log.i(TAG,"now "+resultDTO);
        resultDTOs = resultDTO.getResult();
        Log.i(TAG,"now "+resultDTOs);
        aqiDTO = resultDTOs.getAqi();
        Log.i(TAG,"now "+aqiDTO);
        aqiinfoDTO = aqiDTO.getAqiinfo();
        Log.i(TAG,"now "+aqiinfoDTO);
        dailyDTOList = resultDTOs.getDaily();
        Log.i(TAG,"now "+dailyDTOList);
        hourlyDTOList = resultDTOs.getHourly();
        Log.i(TAG,"now "+hourlyDTOList);
        indexDTOList = resultDTOs.getIndex();
        Log.i(TAG,"now "+indexDTOList);
    }

    //显示天气数据
    private void showdata() {
        int hour = getHours( "0" );
        if(hour > 6 && hour < 18) {
            settextcolor( "#000000" );
            city_add_can.setBackground(  ActivityCompat.getDrawable( getApplicationContext(), R.drawable.black ) );
            color7.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.white) );
            color14.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.white) );
            quality.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.white) );
        }
        else {
            settextcolor( "#FFFFFF" );
            city_add_can.setBackground(  ActivityCompat.getDrawable( getApplicationContext(), R.drawable.white ) );
            color7.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.black) );
            color14.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.black) );
            quality.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.black) );
        }
        city.setText(resultDTOs.getCity());
        temp.setText(resultDTOs.getTemp());
        weather.setText(resultDTOs.getWeather());
        data.setText(resultDTOs.getDate());
        hightemp.setText(resultDTOs.getTemphigh());
        lowtemp.setText(resultDTOs.getTemplow());
        week.setText( resultDTOs.getWeek() );
        quality.setText( aqiDTO.getQuality() );

        LinearLayout linearLayout = findViewById(R.id.hourly);
        linearLayout.removeAllViews();
        LinearLayout onecol = null;
        for(int i = 0;i < hourlyDTOList.size();i++) {
            hourlyDTO = hourlyDTOList.get( i );
            onecol = new LinearLayout( getApplicationContext() );
            onecol.setOrientation( LinearLayout.VERTICAL );
            linearLayout.addView( onecol );
            View view = getLayoutInflater().inflate(R.layout.hourly_text,null);
            TextView hourly_hourly = view.findViewById( R.id.hourly_hourly );
            TextView hourly_temp = view.findViewById( R.id.hourly_temp );
            Button hourly_weather = view.findViewById( R.id.hourly_weather );
            TextView color1 = view.findViewById( R.id.color1 );
            int hours = getHours( hourlyDTO.getTime());
            hourly_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_yin ) );
            weatherjudge( hourly_weather, hourlyDTO.getWeather() ,hours);
            hourly_hourly.setText( hourlyDTO.getTime() );
            hourly_temp.setText( hourlyDTO.getTemp() );
            int nowhour = getHours( "0" );
            if(nowhour > 6 && nowhour < 18) {
                color1.setTextColor( Color.parseColor( "#000000" ) );
                hourly_temp.setTextColor( Color.parseColor("#000000") );
                hourly_hourly.setTextColor( Color.parseColor("#000000") );
            }
            else {
                color1.setTextColor( Color.parseColor( "#FFFFFF" ) );
                hourly_temp.setTextColor( Color.parseColor("#FFFFFF") );
                hourly_hourly.setTextColor( Color.parseColor("#FFFFFF") );
            }
            onecol.addView( view );
        }

        linearLayout = findViewById(R.id.forecast_s);
        linearLayout.removeAllViews();

        for(int i = 0;i < dailyDTOList.size();i++) {
            dailyDTO = dailyDTOList.get( i );
            dayDTO = dailyDTO.getDay();
            nightDTO = dailyDTO.getNight();


            View view = getLayoutInflater().inflate(R.layout.forecast_daily,null);
            TextView week = view.findViewById( R.id.week );
            TextView weather = view.findViewById( R.id.weather );
            TextView lowtemp = view.findViewById( R.id.lowtemp );
            TextView hightemp = view.findViewById( R.id.hightemp );
            TextView color2 = view.findViewById( R.id.color2 );
            TextView color3 = view.findViewById( R.id.color3 );
            Button daily_weather = (Button) view.findViewById( R.id.daily_weather );
            daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_qing ) );


            linearLayout.addView( view );

            int hours = getHours("0" );
            if(hours>6 && hours<18){
                Log.i(TAG,"白天 "+hours);
                weatherjudge( daily_weather, dayDTO.getWeather(),hours );
                week.setText( dailyDTO.getWeek() );
                weather.setText( dayDTO.getWeather() );
                hightemp.setText( resultDTOs.getTemphigh() );
                lowtemp.setText( resultDTOs.getTemplow() );
                week.setTextColor( Color.parseColor("#000000") );
                weather.setTextColor( Color.parseColor("#000000") );
                hightemp.setTextColor( Color.parseColor("#000000") );
                lowtemp.setTextColor( Color.parseColor("#000000") );
                color2.setTextColor( Color.parseColor("#000000") );
                color3.setTextColor( Color.parseColor("#000000") );
            }else {
                week.setTextColor( Color.parseColor("#FFFFFF") );
                weather.setTextColor( Color.parseColor("#FFFFFF") );
                hightemp.setTextColor( Color.parseColor("#FFFFFF") );
                lowtemp.setTextColor( Color.parseColor("#FFFFFF") );
                color2.setTextColor( Color.parseColor("#FFFFFF") );
                color3.setTextColor( Color.parseColor("#FFFFFF") );
                Log.i(TAG,"晚上 "+hours);
                weatherjudge( daily_weather, nightDTO.getWeather(),hours );
                week.setText( dailyDTO.getWeek() );
                weather.setText( nightDTO.getWeather() );
                hightemp.setText( resultDTOs.getTemphigh() );
                lowtemp.setText( resultDTOs.getTemplow() );
            }

        }
        //设置背景
        setbackground(hour);
    }

    //设置字体颜色
    private void settextcolor(String s) {
        city.setTextColor( Color.parseColor( s ) );
        temp.setTextColor( Color.parseColor( s ) );
        weather.setTextColor( Color.parseColor( s ) );
        data.setTextColor( Color.parseColor( s ) );
        hightemp.setTextColor( Color.parseColor( s ) );
        lowtemp.setTextColor( Color.parseColor( s ) );
        week.setTextColor( Color.parseColor( s ) );
        color4.setTextColor( Color.parseColor( s ) );
        color5.setTextColor( Color.parseColor( s ) );
        color6.setTextColor( Color.parseColor( s ) );
        color7.setTextColor( Color.parseColor( s ) );
        color14.setTextColor( Color.parseColor( s ) );
        quality.setTextColor( Color.parseColor( s ) );
    }

    private int getHours(String nowtime) {
        TimeZone.setDefault( TimeZone.getTimeZone( "Asia/Shanghai" ) );
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = "2021-12-12 "+nowtime+":59";
        Log.i( TAG,"date "+nowtime );

        if(nowtime.equals( "0" )) {
            date = df.format( new Date() );
        }
        try {
            Date localdate = df.parse( date );
            Log.i( TAG,"date "+localdate+" "+localdate.getHours() );
            return localdate.getHours();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private void weatherjudge(Button daily_weather, String weather2,int hours) {
        switch (weather2) {
            case "暴雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_dayu ) );
                break;
            case "雷阵雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_leizhenyu ) );
                break;
            case "大雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_dayu ) );
                break;
            case "中雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_xiaoyu ) );
                break;
            case "小雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_xiaoyu ) );
                break;
            case "阵雨":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_zhenyu ) );
                break;
            case "多云":
                if(hours>6 && hours<18){
                    Log.i(TAG,"now 白天 "+hours);
                    daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_duoyun ) );
                } else {
                    Log.i(TAG,"now 晚上 "+hours);
                    daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_nightduoyun ) );
                }
                break;
            case "阴":
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_yin ) );
                break;
            case "晴":
                if(hours>6 && hours<18){
                    Log.i(TAG,"now 白天 "+hours);
                    daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_qing ) );
                } else {
                    Log.i(TAG,"now 晚上 "+hours);
                    daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_nightqing ) );
                }
                break;
            case "小雪" :
                daily_weather.setBackground( ActivityCompat.getDrawable( getApplicationContext(), R.drawable.new_xiaoxue ) );
                break;
        }
    }

    //设置天气背景
    private void setbackground(int hour){
        background_iv.setBackgroundResource(R.drawable.moren);
        if (animation!=null){
            animation.stop();
            animation = null;
        }
        switch (resultDTOs.getWeather()){
            case "暴雨":
                background_iv.setBackgroundResource(R.drawable.baoyu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "雷阵雨":
                background_iv.setBackgroundResource(R.drawable.baoyu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "大雨":
                background_iv.setBackgroundResource(R.drawable.dayu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "中雨":
                background_iv.setBackgroundResource(R.drawable.dayu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "小雨":
                background_iv.setBackgroundResource(R.drawable.xiaoyu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "阵雨":
                background_iv.setBackgroundResource(R.drawable.xiaoyu_frame);
                animation = (AnimationDrawable) background_iv.getBackground();
                animation.start();
                break;
            case "小雪" :
                background_iv.setBackgroundResource(R.drawable.xueday2);
                break;
            case "大雪" :
                background_iv.setBackgroundResource(R.drawable.xueday);
                break;
            case "雾" :
                background_iv.setBackgroundResource(R.drawable.wuday);
                break;
            case "霾" :
            background_iv.setBackgroundResource(R.drawable.maiday);
            break;
            case "多云":
                if(hour > 6 && hour < 18) {
                    background_iv.setBackgroundResource( R.drawable.duoyunday );
                } else {
                    background_iv.setBackgroundResource( R.drawable.nighduoyun2 );
                }
                break;
            case "阴":
                background_iv.setBackgroundResource(R.drawable.yin_day);
                break;
            case "晴":
                if(hour > 6 && hour < 18) {
                    background_iv.setBackgroundResource( R.drawable.qing );
                } else {
                    background_iv.setBackgroundResource( R.drawable.qing_night );
                }
                break;
        }
    }

    public void handle_arequality(View view) {
        if (json != null) {
            Log.i(TAG,"now "+json);
            SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("json",json);
            editor.commit();
            startActivity(new Intent(getApplicationContext(),QualityActivity.class));
        } else {
            //否则提示没有网络
            Toast.makeText(MainActivity.this, "请检查网络", Toast.LENGTH_SHORT).show();
            //尝试获取json数据
            getJson(cityName);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPreferences = getSharedPreferences( "user",MODE_PRIVATE );
        cityName = sharedPreferences.getString( "cityname" , "藤县" );

        Log.i( TAG,"now 肯定是到了这里 onStart "+ cityName);
        getJson( cityName );
    }

    public void handle_add(View view) {
        Log.i( TAG,"啥啊，我服了。" );
        startActivity(new Intent(getApplicationContext(),CityActivity.class));
    }

    public void handle_weather(View view) {
        if (json != null) {
            Log.i(TAG,"now "+json);
            SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("json",json);
            editor.commit();
            startActivity(new Intent(getApplicationContext(),WeatherActivity.class));
        } else {
            //否则提示没有网络
            Toast.makeText(MainActivity.this, "请检查网络", Toast.LENGTH_SHORT).show();
            //尝试获取json数据
            getJson(cityName);
        }
    }

    public void handle_live(View view) {
        if (json != null) {
            Log.i(TAG,"now "+json);
            SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("json",json);
            editor.commit();
            startActivity(new Intent(getApplicationContext(),LiveActivity.class));
        } else {
            //否则提示没有网络
            Toast.makeText(MainActivity.this, "请检查网络", Toast.LENGTH_SHORT).show();
            //尝试获取json数据
            getJson(cityName);
        }
    }

    //辅助存放实体类
    class JsonAndTime{
        private Long currentTime;
        private String json;

        public JsonAndTime(Long currentTime, String json) {
            this.currentTime = currentTime;
            this.json = json;
        }

        public Long getCurrentTime() {
            return currentTime;
        }

        public void setCurrentTime(Long currentTime) {
            this.currentTime = currentTime;
        }

        public String getJson() {
            return json;
        }

        public void setJson(String json) {
            this.json = json;
        }

        @Override
        public String toString() {
            return "JsonAndTime{" +
                    "currentTime=" + currentTime +
                    ", json='" + json + '\'' +
                    '}';
        }
    }
}
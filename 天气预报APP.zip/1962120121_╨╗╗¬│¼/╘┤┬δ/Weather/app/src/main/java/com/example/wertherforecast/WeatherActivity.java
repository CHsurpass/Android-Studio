package com.example.wertherforecast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;

public class WeatherActivity extends AppCompatActivity {

    //打印异常
    private static final String TAG = WeatherActivity.class.getSimpleName();
    //定义对象
    private WeatherBean weatherBean;
    private WeatherBean.ResultDTO resultDTO;
    private WeatherBean.ResultDTO.ResultsDTO resultDTOs;
    private String json;
    //定义控件
    private TextView windpower;
    private TextView humidity;
    private TextView pressure;
    private TextView windspeed;
    private TextView winddirect;
    private TextView bodytemp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        //加载界面布局
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_weather );
        //初始化控件
        initview();
        //获取mainactivity共享的信息
        SharedPreferences sp = getSharedPreferences( "user",MODE_PRIVATE );
        json = sp.getString( "json", String.valueOf( 0 ) );
        Log.i( TAG,"weather "+json );
        //gson解析json
        gsonObject(json);
        //显示数据到控件
        showdata();
    }

    //初始化控件
    private void initview() {
        windpower = findViewById( R.id.windpower );
        humidity = findViewById( R.id.humidity );
        pressure = findViewById( R.id.pressure );
        windspeed = findViewById( R.id.windspeed );
        winddirect = findViewById( R.id.winddirect );
        bodytemp = findViewById( R.id.bodytemp );
    }
    //显示天气数据
    private void showdata() {
        bodytemp.setText( resultDTOs.getTemp() );
        windpower.setText( resultDTOs.getWindpower() );
        humidity.setText( resultDTOs.getHumidity() );
        pressure.setText( resultDTOs.getPressure() );
        windspeed.setText( resultDTOs.getWindspeed() );
        winddirect.setText( resultDTOs.getWinddirect() );
        Log.i( TAG,"temp "+resultDTOs.getTemp() );
    }

    //gson解析
    private void gsonObject(String json) {
        //创建gson对象
        Gson gson = new Gson();
        //gson解析获得weatherBean对象
        weatherBean = gson.fromJson(json, WeatherBean.class);
        Log.i(TAG,"weather "+weatherBean);
        //从weatherBean对象中获取cityInfo对象
        resultDTO = weatherBean.getResult();
        Log.i(TAG,"weather "+resultDTO);
        //从weatherBean对象中获取data对象
        resultDTOs = resultDTO.getResult();
        Log.i(TAG,"weather "+resultDTOs);
    }
}
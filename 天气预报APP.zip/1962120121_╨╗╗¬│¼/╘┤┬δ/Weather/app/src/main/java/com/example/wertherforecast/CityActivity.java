package com.example.wertherforecast;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.List;

public class CityActivity extends AppCompatActivity {
    private static final String TAG = CityActivity.class.getSimpleName();
    //控件
    private ListView city_lv;
    private List<CityBean.ResultDTO.ResultsDTO> cityBeanList;
    private Button search_ibtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        Log.i( TAG,"onCreate "+"CityActivity" );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city);
        //初始化控件
        initview();
        //设置下拉菜单
        //获取数据
        cityBeanList = new DBUtils(this).selectmycity();
        //设置listview显示数据
        setCity_lv(cityBeanList);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //获取数据
        cityBeanList = new DBUtils(this).selectmycity();
        Log.i( TAG,"onStart "+ cityBeanList);
        //设置listview显示数据
        setCity_lv(cityBeanList);
    }

    //初始化控件
    private void initview() {
        city_lv = findViewById(R.id.city_lv);
        search_ibtn = findViewById( R.id.search_ibtn );

    }

    //设置listview显示数据
    private void setCity_lv(List<CityBean.ResultDTO.ResultsDTO> list) {
        search_ibtn.setBackground( ActivityCompat.getDrawable( getApplicationContext(),R.drawable.add) );
        Log.i(TAG,"setCity_lv "+"添加了控件");
        //创建适配器
        CityAdapter adapter = new CityAdapter(this, R.layout.city_item, cityBeanList);
        //设置适配器
        city_lv.setAdapter(adapter);
        //设置点击事件
        adapter.setOnItemClickListener(new CityAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(CityBean.ResultDTO.ResultsDTO cityBean) {
                System.out.println("点击了" + cityBean.getCity());
                SharedPreferences sp = getSharedPreferences("user",MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("cityname",cityBean.getCity());
                editor.commit();
                CityActivity.this.finish();
            }
            @Override
            public void onCancelClick(CityBean.ResultDTO.ResultsDTO cityBean) {
                //使用数据库工具类删除点击的城市
                new DBUtils(CityActivity.this).deletemycity(cityBean.getCity());
                //重新获取数据
                cityBeanList = new DBUtils(CityActivity.this).selectmycity();
                //设置listview显示数据
                setCity_lv(cityBeanList);
            }
        });
    }

    public void handle_addcity(View view) {
        Log.i(TAG,"onClick "+"我要搜索");
        Intent intent = new Intent(CityActivity.this, SearchActivity.class);
        startActivity(intent);
    }

}

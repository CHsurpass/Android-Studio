package com.example.wertherforecast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.List;

public class LiveActivity extends AppCompatActivity {
    //打印异常
    private static final String TAG = LiveActivity.class.getSimpleName();
    //定义对象
    private WeatherBean weatherBean;
    private WeatherBean.ResultDTO resultDTO;
    private WeatherBean.ResultDTO.ResultsDTO resultDTOs;
    private WeatherBean.ResultDTO.ResultsDTO.IndexDTO indexDTO;
    private List<WeatherBean.ResultDTO.ResultsDTO.IndexDTO> indexDTOList;
    private String json;
    //定义控件
    private TextView sport;
    private TextView chuanyi;
    private TextView watercar;
    private TextView ganmao;
    private TextView kongtiao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        getSupportActionBar().hide();
        setContentView( R.layout.activity_live );
        //初始化控件
        initview();
        //获取mainactivity共享的信息
        SharedPreferences sp = getSharedPreferences( "user",MODE_PRIVATE );
        json = sp.getString( "json", String.valueOf( 0 ) );
        Log.i( TAG,"qq"+json );
        //gson解析json
        gsonObject(json);
        //显示数据到控件
        showdata();
    }

    //初始化控件
    private void initview() {
        sport = findViewById( R.id.sport );
        kongtiao = findViewById( R.id.kongtiao );
        ganmao = findViewById( R.id.ganmao );
        chuanyi = findViewById( R.id.chuanyi );
        watercar = findViewById( R.id.watercar );
    }
    //显示天气数据
    private void showdata() {
        indexjudge( "运动指数", sport );
        indexjudge( "洗车指数", watercar );
        indexjudge( "空调指数", kongtiao );
        indexjudge( "感冒指数", ganmao );
        indexjudge( "穿衣指数", chuanyi );
    }

    private void indexjudge(String iname, TextView watercar) {
        for (int i = 0; i < indexDTOList.size(); i++) {
            indexDTO = indexDTOList.get( i );
            if (indexDTO.getIname().equals( iname )) {
                watercar.setText( indexDTO.getIvalue() );
                Log.i( TAG,"now zhishu "+indexDTO.getIname()+indexDTO.getIvalue() );
            }
        }
    }

    //gson解析
    private void gsonObject(String json) {
        //创建gson对象
        Gson gson = new Gson();
        //gson解析获得weatherBean对象
        weatherBean = gson.fromJson( this.json, WeatherBean.class);
        Log.i(TAG,"Live "+weatherBean);
        //从weatherBean对象中获取cityInfo对象
        resultDTO = weatherBean.getResult();
        Log.i(TAG,"Live "+resultDTO);
        resultDTOs = resultDTO.getResult();
        Log.i(TAG,"Live "+resultDTOs);
        indexDTOList = resultDTOs.getIndex();
        Log.i(TAG,"Live "+indexDTOList);
    }
}
package com.example.wertherforecast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;

public class QualityActivity extends AppCompatActivity {
    //打印异常
    private static final String TAG = QualityActivity.class.getSimpleName();
    //定义对象
    private WeatherBean weatherBean;
    private WeatherBean.ResultDTO resultDTO;
    private WeatherBean.ResultDTO.ResultsDTO resultDTOs;
    private WeatherBean.ResultDTO.ResultsDTO.AqiDTO aqiDTO;
    private WeatherBean.ResultDTO.ResultsDTO.AqiDTO.AqiinfoDTO aqiinfoDTO;
    private String json;
    //定义控件
    private TextView quality_aqi;
    private TextView quality_pm25;
    private TextView quality_no2;
    private TextView quality_o3;
    private TextView quality_pm10;
    private TextView quality_co;
    private TextView quality_so2;
    private TextView level;
    private TextView affect;
    private TextView measure;
    private TextView quality_quality;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //加载界面布局
        super.onCreate( savedInstanceState );
        getSupportActionBar().hide();
        setContentView( R.layout.activity_quality );
        //初始化控件
        initview();
        //获取mainactivity共享的信息
        SharedPreferences sp = getSharedPreferences( "user",MODE_PRIVATE );
        json = sp.getString( "json", String.valueOf( 0 ) );
        Log.i( TAG,"qq"+json );
        //gson解析json
        gsonObject(json);
        //显示数据到控件
        showdata();
    }

    //初始化控件
    private void initview() {
        quality_aqi = findViewById(R.id.quality_aqi);
        quality_pm25 = findViewById(R.id.quality_pm25);
        quality_no2 = findViewById(R.id.quality_no2);
        quality_o3 = findViewById( R.id.quality_o3 );
        quality_pm10 = findViewById(R.id.quality_pm10);
        quality_co = findViewById(R.id.quality_co);
        quality_so2 = findViewById(R.id.quality_so2);
        level = findViewById( R.id.level );
        affect = findViewById( R.id.affect );
        measure = findViewById( R.id.measure );
        quality_quality = findViewById( R.id.quality_quality );
    }
    //显示天气数据
    private void showdata() {
        quality_aqi.setText( aqiDTO.getAqi() );
        quality_aqi.setTextColor( Color.parseColor(aqiinfoDTO.getColor()) );
        quality_quality.setText( aqiDTO.getQuality() );
        quality_quality.setTextColor( Color.parseColor( aqiinfoDTO.getColor() ) );
        quality_o3.setText( aqiDTO.getO3() );
        quality_pm25.setText( aqiDTO.getPm2_5() );
        quality_no2.setText( aqiDTO.getNo2() );
        quality_pm10.setText( aqiDTO.getPm10() );
        quality_co.setText( aqiDTO.getCo());
        quality_so2.setText( aqiDTO.getSo2() );
        level.setText( aqiinfoDTO.getLevel() );
        level.setTextColor( Color.parseColor( aqiinfoDTO.getColor() ) );
        affect.setText( aqiinfoDTO.getAffect() );
        measure.setText( aqiinfoDTO.getMeasure() );
        Log.i( TAG,"pm"+aqiDTO.getPm10() );
    }


    //gson解析
    private void gsonObject(String json) {
        //创建gson对象
        Gson gson = new Gson();
        //gson解析获得weatherBean对象
        weatherBean = gson.fromJson(json, WeatherBean.class);
        Log.i(TAG,"now "+weatherBean);
        //从weatherBean对象中获取cityInfo对象
        resultDTO = weatherBean.getResult();
        Log.i(TAG,"now "+resultDTO);
        //从weatherBean对象中获取data对象
        resultDTOs = resultDTO.getResult();
        Log.i(TAG,"now "+resultDTOs);
        //获取forcast列对象
        aqiDTO = resultDTOs.getAqi();
        Log.i(TAG,"now "+aqiDTO);
        aqiinfoDTO = aqiDTO.getAqiinfo();
        Log.i(TAG,"now "+aqiinfoDTO);
    }
}
package com.example.wertherforecast;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBUtils {
    private DBOpenHelper OpenHelper;

    public DBUtils(Context context){
        System.out.println("我要创建数据库");
        OpenHelper = new DBOpenHelper(context);
        System.out.println("我创建好数据库了");
    }

    //查询所有城市记录
    public List<CityBean.ResultDTO.ResultsDTO> select(){
        List<CityBean.ResultDTO.ResultsDTO> list = new ArrayList<CityBean.ResultDTO.ResultsDTO>();
        SQLiteDatabase db = OpenHelper.getWritableDatabase();
        String sql = "select * from citythree";
        Cursor cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            CityBean.ResultDTO.ResultsDTO cityBean= new CityBean.ResultDTO.ResultsDTO();
            cityBean.setCityid(cursor.getString(0));
            cityBean.setCity(cursor.getString(1));
            cityBean.setCitycode(cursor.getString(2));
            list.add(cityBean);
        }
        cursor.close();
        db.close();
        return list;
    }

    //通过拼音查询城市记录
    public List<CityBean.ResultDTO.ResultsDTO> select(String pinyin){
        List<CityBean.ResultDTO.ResultsDTO> list = new ArrayList<CityBean.ResultDTO.ResultsDTO>();
        SQLiteDatabase db = OpenHelper.getWritableDatabase();
        String sql = "select * from citythree where pinyin || name like '%" + pinyin + "%'";
        Cursor cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            CityBean.ResultDTO.ResultsDTO cityBean= new CityBean.ResultDTO.ResultsDTO();
            cityBean.setCityid(cursor.getString(0));
            cityBean.setCity(cursor.getString(1));
            cityBean.setCitycode(cursor.getString(2));
            list.add(cityBean);
        }
        cursor.close();
        db.close();
        return list;
    }

    //展示城市记录
    public List<CityBean.ResultDTO.ResultsDTO> selectmycity(){
        List<CityBean.ResultDTO.ResultsDTO> list = new ArrayList<CityBean.ResultDTO.ResultsDTO>();
        SQLiteDatabase db = OpenHelper.getWritableDatabase();
        String sql = "select * from citythree where mark = 1";
        System.out.println("我在展示城市呢");
        Cursor cursor = db.rawQuery(sql,null);
        System.out.println("我在展示城市呢2a ");
        while (cursor.moveToNext()) {
            CityBean.ResultDTO.ResultsDTO cityBean= new CityBean.ResultDTO.ResultsDTO();
            cityBean.setCityid( cursor.getString(0));
            cityBean.setCity(cursor.getString(1));
            cityBean.setCitycode(cursor.getString(2));
            list.add(cityBean);
            System.out.println("我在展示城市ing: "+cityBean);
        }

        System.out.println("我在展示完城市了：");
        cursor.close();
        db.close();
        return list;
    }

    public void savemycity(String cityname){
        SQLiteDatabase db = OpenHelper.getWritableDatabase();
        String sql = "update citythree set mark = 1 where name = '" + cityname + "'";
        db.execSQL(sql);
        db.close();
    }

    public void deletemycity(String cityname){
        SQLiteDatabase db = OpenHelper.getWritableDatabase();
        String sql = "update citythree set mark = 0 where name = '" + cityname + "'";
        db.execSQL(sql);
        db.close();
    }

}
